from openai import OpenAI

client = OpenAI(api_key="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")

models = client.models.list()

for model in models.data:
    print(model.id)
