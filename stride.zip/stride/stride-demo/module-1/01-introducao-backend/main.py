import os
import base64
import tempfile
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, Form, File
from fastapi.responses import JSONResponse
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
import requests

# Load .env
env_path = Path(__file__).resolve(strict=True).parent / ".env"
load_dotenv(dotenv_path=env_path)

# Hugging Face Token
HUGGINGFACE_API_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN")
if not HUGGINGFACE_API_TOKEN:
    raise ValueError("HUGGINGFACE_API_TOKEN não está definido no arquivo .env")

# FastAPI config
# app = FastAPI()
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

app = FastAPI(docs_url="/docs", redoc_url=None, openapi_url="/openapi.json")


# Prompt base
def criar_prompt_modelo_ameacas(tipo_aplicacao, autenticacao, acesso_internet, dados_sensiveis, descricao_aplicacao):
    return f"""
Aja como um especialista em cibersegurança com mais de 20 anos de experiência utilizando a metodologia STRIDE.

TIPO DE APLICAÇÃO: {tipo_aplicacao}
AUTENTICAÇÃO: {autenticacao}
ACESSO À INTERNET: {acesso_internet}
DADOS SENSÍVEIS: {dados_sensiveis}
DESCRIÇÃO DA APLICAÇÃO: {descricao_aplicacao}

Forneça uma saída JSON no formato:
{{
  "threat_model": [
    {{
      "Threat Type": "Spoofing",
      "Scenario": "Exemplo",
      "Potential Impact": "Exemplo"
    }}
  ],
  "improvement_suggestions": [
    "Exemplo de sugestão de melhoria"
  ]
}}
"""

# Endpoint
@app.post("/analisar_ameacas")
async def analisar_ameacas(
    imagem: UploadFile = File(...),
    tipo_aplicacao: str = Form(...),
    autenticacao: str = Form(...),
    acesso_internet: str = Form(...),
    dados_sensiveis: str = Form(...),
    descricao_aplicacao: str = Form(...)
):
    try:
        # Lê a imagem
        content = await imagem.read()
        with tempfile.NamedTemporaryFile(delete=False, suffix=Path(imagem.filename).suffix) as temp_file:
            temp_file.write(content)
            temp_file_path = temp_file.name

        # Codifica imagem base64
        with open(temp_file_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('ascii')

        os.remove(temp_file_path)

        # Cria o prompt
        prompt_text = criar_prompt_modelo_ameacas(tipo_aplicacao, autenticacao, acesso_internet, dados_sensiveis, descricao_aplicacao)

        prompt_completo = f"{prompt_text}\n\nA imagem da arquitetura (codificada em base64) é:\n{encoded_string[:500]}...[truncated]"

        # Envia para Hugging Face
        API_URL = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1"
        headers = {"Authorization": f"Bearer {HUGGINGFACE_API_TOKEN}"}

        payload = {"inputs": prompt_completo}
        response = requests.post(API_URL, headers=headers, json=payload)

        if response.status_code != 200:
            return JSONResponse(status_code=500, content={"error": f"Erro na API Hugging Face: {response.text}"})

        return JSONResponse(content=response.json())

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
